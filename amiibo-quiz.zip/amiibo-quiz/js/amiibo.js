"use strict";
window.onload = init;

// Variables to keep track of data
let amiibos = [];
let characters = [];
let games = [];
let currentCharacter = {};
let characterDrop;
let gameDrop;
let image;
let skip;
let submit;
let restart;
let skipsRemaining = 3;
let skipInfo;
let lives = 3;
let lifeInfo;
let score = 0;
let scoreInfo;
let highScore = 0;
let highScoreInfo;
const prefix = "jcc4331-";
const storedScoreKey = prefix + "score";
const storedScore = localStorage.getItem(storedScoreKey);

function init() {
	// Get the data
	getData();

	// Store references to dropdowns and buttons
	characterDrop = document.querySelector("#characters");
	gameDrop = document.querySelector("#series");
	image = document.querySelector("#currentCharacter");
	submit = document.querySelector("#submit");
	skip = document.querySelector("#skip");
	restart = document.querySelector("#restart");

	// Display skips available at the beginning
	skipInfo = document.querySelector("#remaining");
	skipInfo.innerHTML = "Skips Remaining: " + skipsRemaining;
	scoreInfo = document.querySelector("#score");
	scoreInfo.innerHTML = "Score: " + score;
	lifeInfo = document.querySelector("p");
	lifeInfo.innerHTML = "Lives: " + lives;
	highScoreInfo = document.querySelector("h3");
	highScoreInfo.innerHTML = "Highscore: " + highScore

	// Establish submit button on click
	submit.onclick = function () {

		// Get the value of the game drop down
		// BECAUSE FOR SOME REASON VALUE ONLY TAKES THE FIRST WORD
		let why = currentCharacter.series.split(" ")[0];

		// Proceed if there are lives remaining
		if(lives > 0){
		// If the current character and game guess are correct, increase points
		if (characterDrop.value == currentCharacter.character
			&& gameDrop.value == why) {
			score++;
			scoreInfo.innerHTML = "Score: " + score;
		}
		// If it isn't, lose a life
		else {
			lives--;
			if(score != 0){
			score--;
			}
			scoreInfo.innerHTML = "Score: " + score;
			lifeInfo.innerHTML = "Lives: " + lives;
			if(lives == 0){
				highScore = score;
				highScoreInfo.innerHTML = "Highscore: " + highScore;
				localStorage.setItem(storedScoreKey, highScore);
			}
		}

		// Get a new character.
		GetAmiibo();
	}
	}
	// Establish skip button on click
	skip.onclick = function () {
		
		// If there are skips remaining,
		// choose a new character and lose a skip.
		if(skipsRemaining > 0){
			
			// Get a new character
			GetAmiibo();

			// Update skips and display
			skipsRemaining--;
			skipInfo.innerHTML = "Skips Remaining: " + skipsRemaining;
		}
	}

	restart.onclick = function () {
		GetAmiibo();
		score = 0;
		lives = 3;
		skipsRemaining = 3;
		scoreInfo.innerHTML = "Score: " + score;
		lifeInfo.innerHTML = "Lives: " + lives;
		skipInfo.innerHTML = "Skips Remaining: " + skipsRemaining;
	}
}

function getData() {
	// 1 - main entry point to web service
	const SERVICE_URL = "https://www.amiiboapi.com/api/amiibo/";
	// 5 - create a new XHR object
	let xhr = new XMLHttpRequest();


	// 6 - set the onload handler
	xhr.onload = dataLoaded;

	// 7 - set the onerror handler
	xhr.onerror = dataError;

	// 8 - open connection and send the request
	xhr.open("GET", SERVICE_URL);
	xhr.send();
}
function dataError(e) {
	console.log("An error occurred");
}
function dataLoaded(e) {
	// 1 - e.target is the xhr object
	let xhr = e.target;

	// 2 - xhr.responseText is the JSON file we just downloaded
	//console.log(xhr.responseText);

	// 3 - turn the text into a parsable JavaScript object
	let obj = JSON.parse(xhr.responseText);


	// Get the entire log of amiibos to choose from
	let results = obj.amiibo;
	for (let i = 0; i < results.length; i++) {
		let amiiboCharacter = {};

		amiiboCharacter.character = results[i].character;
		amiiboCharacter.series = results[i].gameSeries;
		amiiboCharacter.image = results[i].image;
		amiibos.push(amiiboCharacter);
		characters.push(amiiboCharacter.character);
		games.push(amiiboCharacter.series);

	}

	characters = characters.sort();
	characters = [... new Set(characters)];
	games = games.sort();
	games = [... new Set(games)];


	for (let i = 0; i < characters.length; i++) {
		characterDrop.innerHTML += "<option value=" + characters[i] + ">" + characters[i] + "</option>"
	}
	for (let i = 0; i < games.length; i++) {
		gameDrop.innerHTML += "<option value=" + games[i] + ">" + games[i] + "</option>"
	}
	GetAmiibo();
}

function dataError(e) {
	console.log("An error occurred");
}
function dataLoaded(e) {
	// 1 - e.target is the xhr object
	let xhr = e.target;

	// 2 - xhr.responseText is the JSON file we just downloaded
	//console.log(xhr.responseText);

	// 3 - turn the text into a parsable JavaScript object
	let obj = JSON.parse(xhr.responseText);


	// Get the entire log of amiibos to choose from
	let results = obj.amiibo;
	for (let i = 0; i < results.length; i++) {
		let amiiboCharacter = {};

			amiiboCharacter.character = results[i].character;
			amiiboCharacter.series = results[i].gameSeries;
			amiiboCharacter.image = results[i].image;
			amiibos.push(amiiboCharacter);
			characters.push(amiiboCharacter.character);
			games.push(amiiboCharacter.series);
		
	}

	characters = characters.sort();
	characters = [... new Set(characters)];
	games = games.sort();
	games = [... new Set(games)];


	for (let i = 0; i < characters.length; i++) {
		characterDrop.innerHTML += "<option value=" + characters[i] + ">" + characters[i] + "</option>"
	}
	for (let i = 0; i < games.length; i++) {
		gameDrop.innerHTML += "<option value=" + games[i] + ">" + games[i] + "</option>"
	}
	GetAmiibo();	
}

function GetAmiibo() {
	currentCharacter = amiibos[Math.floor(Math.random() * amiibos.length)];
	image.innerHTML = "<img src = '" + currentCharacter.image + "' alt = 'character' id = 'chosen'>";
}
